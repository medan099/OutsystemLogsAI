import json
from langchain_community.llms import Ollama
from utils import prepare_documents, create_retriever, create_qa_chain, generate_solutions

# Fonction d'initialisation une seule fois
def initialize_system():
    with open('preprocessed_data.json') as f:
        data = json.load(f)

    documents = prepare_documents(data)
    retriever = create_retriever(documents)
    llm = Ollama(model="phi3")
    qa_chain = create_qa_chain(retriever, llm)
    return qa_chain, llm
