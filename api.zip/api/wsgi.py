# wsgi.py

from api import app
from fastapi.middleware.wsgi import WSGIMiddleware

application = WSGIMiddleware(app)
