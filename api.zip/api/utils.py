from langchain.schema import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA

# 1. Préparer les documents
def prepare_documents(data):
    documents = []

    for post in data["posts"]:
        problem = post["problem"].lower()

        is_error = any(kw in problem for kw in ['error', 'fail', 'bug', 'issue', 'exception'])

        for sol in post["solutions"]:
            is_visual = "[Technical Screenshot:" in sol
            has_code = any(x in sol for x in ['=', '(', '{', 'http'])

            documents.append(Document(
                page_content=f"PROBLEM: {post['problem']}\nSOLUTION: {sol}",
                metadata={
                    "is_error": is_error,
                    "is_visual": is_visual,
                    "has_code": has_code,
                    "source": "dataset"
                }
            ))
    return documents

# 2. Créer le retriever intelligent
def create_retriever(documents):
    embedding = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.from_documents(documents, embedding)

    def smart_search(query, k=3):
        results = vectorstore.similarity_search(query, k=k*2)

        results.sort(key=lambda x: (
            x.metadata["is_error"],
            x.metadata["is_visual"],
            x.metadata["has_code"]
        ), reverse=True)

        return results[:k]

    return vectorstore.as_retriever(search_func=smart_search)

# 3. Construire la chaîne QA
def create_qa_chain(retriever, llm):
    template = """Analyze this issue using available knowledge:

{context}

Question: {question}

Respond with:
1. Problem Type:
2. Likely Causes:
3. Recommended Actions:"""

    return RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={
            "prompt": PromptTemplate.from_template(template),
            "document_separator": "\n=== EXAMPLE ===\n"
        }
    )

# 4. Générer la solution finale
def generate_solutions(user_query, qa_chain, llm):
    try:
        result = qa_chain.invoke({"query": user_query})
        sources = result.get("source_documents", [])

        if sources and any(doc.metadata["is_error"] for doc in sources):
            answer = "🔧 [Verified Solution]\n" + result["result"]
            refs = "\n".join(
                f"- {doc.page_content.split('SOLUTION:')[1][:150]}..."
                for doc in sources[:3]
            )
            return {
                "answer": f"{answer}\n\n📖 References:\n{refs}",
                "source": "dataset"
            }
        else:
            llm_response = llm.invoke(
                f"Provide concise technical analysis for:\n{user_query}\n"
                "Format:\n1. Issue Category\n2. Troubleshooting Steps\n3. Prevention"
            )
            return {
                "answer": f"💡 [General Guidance]\n{llm_response}",
                "source": "llm"
            }

    except Exception as e:
        return {
            "answer": f"⚠️ Error: {str(e)}",
            "source": "error"
        }
