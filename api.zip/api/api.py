"""from fastapi import FastAPI
from pydantic import BaseModel
from logic import initialize_system
from utils import generate_solutions
import traceback
app = FastAPI()

# Lazy loading
qa_chain = None
llm = None

class LogInput(BaseModel):
    log: str

@app.post("/analyze-log")
def analyze_log(input: LogInput):
    global qa_chain, llm

    try:
        if qa_chain is None or llm is None:
            qa_chain, llm = initialize_system()

        result = generate_solutions(input.log, qa_chain, llm)
        return {
            "answer": result['answer'],
            "source": result['source']
        }

    except Exception as e:
        print("Exception occurred:")
        traceback.print_exc()  # Show full error in terminal
        return {"error": str(e)}"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from logic import initialize_system
from utils import generate_solutions
import traceback

app = FastAPI()

# ✅ Add CORS Middleware to fix frontend/ngrok issues
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins (or restrict if needed)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Preload at startup
print("🔄 Initializing model and chain at startup...")
try:
    qa_chain, llm = initialize_system()
    print("✅ Initialization successful")
except Exception as e:
    print("❌ Failed to initialize system at startup:")
    traceback.print_exc()
    qa_chain, llm = None, None

class LogInput(BaseModel):
    log: str

@app.post("/analyze-log")
def analyze_log(input: LogInput):
    try:
        print("📥 Received log input")
        if qa_chain is None or llm is None:
            return {"error": "Model not loaded. Initialization failed at startup."}

        result = generate_solutions(input.log, qa_chain, llm)
        return {
            "answer": result['answer'],
            "source": result['source']
        }

    except Exception as e:
        print("❌ Unexpected error:")
        traceback.print_exc()
        return {"error": f"Unexpected error: {str(e)}"}
